import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private _http: HttpClient) { }

  url:string = '/assets/data/employee.json';


  getAllEmployees(): Observable<Employee[]> {
   return this._http.get<Employee[]>(this.url);
  }
}
